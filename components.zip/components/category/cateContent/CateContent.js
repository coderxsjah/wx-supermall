// components/category/cateContent/CateContent.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    leftMenuList:{
      type:Array,
    },
    rightContentList:{
      type:Array,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currindex:0,
    Top:0,//右侧距离顶部的位置
  },

  /**
   * 组件的方法列表
   */
  methods: {
    select:function(e){
      this.setData({
        currindex:e.currentTarget.dataset.leftindex,
        Top:0,
      })
    }
  }
})
