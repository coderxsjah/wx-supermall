// components/user/imageBack/ImageBackground.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    userInfo:{
      type:Object,
    },

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    login(){
      wx.navigateTo({
        url: '/pages/login/index',
      });
    }
  }
})
