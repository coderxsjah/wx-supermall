// components/feedback/feedbackContent/FeedbackContent.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    imgs:{
      type:Array,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    textinput:"",//文本域内容
  },
  UpLoadImgs:[],//外网图片链接数组

  /**
   * 组件的方法列表
   */
  methods: {
    upImg(){
      this.triggerEvent("upImg")
    },
    delete(e){
      const index = e.currentTarget.dataset.index;
      this.triggerEvent("delete",index);
    },
    //文本域输入事件
    textInput(e){
      this.setData({
        textinput:e.detail.value
      })
    },
    //提交事件
    submit(e){
      //1.获取文本域内容和图片
      const {textinput,imgs} = this.data;
      //2.判断文本域内容是否有效
      if(!textinput.trim()){
        wx.showToast({
          title: '请输入有效内容',
          icon: 'none',
        });
        return
      }
      //3.将图片上传到专门的图片服务器
      //显示正在加载中
      wx.showLoading({
        title: "正在上传中",
        mask: true,
      });
      if(imgs.length===0){
        console.log("文本上传成功！");
        wx.hideLoading();
          //5.重置页面
          this.setData({
            textinput:"",
            imgs:[]
          })
          wx.navigateBack({
            delta: 1
          });
      }
      else{
        imgs.forEach((v,i)=>{
          wx.uploadFile({//不支持多个文件同时上传
            //要上传的服务器
            url: 'https://images.ac.cn/Home/Index/UploadAction/',//新浪图床
            //文件的路径
            filePath: v,
            //文件的名称， 便于后台获取文件 file
            name: "file",
            //额外的顺带信息
            formData: {},
            success: (result)=>{
              console.log(result);
              // let url = JSON.parse(result.data)
              // this.UpLoadImgs.push(url);
            }
          });
          if(i===imgs.length-1){
            //4.所有图片都获取外网链接之后，就需要提交数据了
            console.log("把所有文本信息和图片都传递到服务器");
            //关闭上传中
            wx.hideLoading();
            //5.重置页面
            this.setData({
              textinput:"",
              imgs:[]
            })
            wx.navigateBack({
              delta: 1
            });
          }
        })
      }
    }
  }
})
