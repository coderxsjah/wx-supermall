// components/common/tab/Tab.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabTitles:{
      type:Array,
    },
    currType:{
      type:Number,
      value:1,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
  },

  /**
   * 组件的方法列表
   */
  methods: {
    tabClick(e){
      //console.log(e);
      const currindex = e.currentTarget.dataset.index;
      this.triggerEvent("tabClick",currindex);
    }
  }
})
