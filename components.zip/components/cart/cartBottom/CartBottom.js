// components/cart/cartBottom/CartBottom.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    allchecked:{
      type:Boolean,
    },
    totalPrice:{
      type:Number,
    },
    totalType:{
      type:Number,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    allChange(){
      this.triggerEvent("allChange");
    },
    cartPay(){
      this.triggerEvent("cartPay");
    }
  }
})
