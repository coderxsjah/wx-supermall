// components/cart/cartList/CartList.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    cartList:{
      type:Array,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    addNum:function(e){
      const index = e.currentTarget.dataset.index
      this.triggerEvent("addNum",index)
    },
    subNum:function(e){
      const index = e.currentTarget.dataset.index
      this.triggerEvent("subNum",index)
    },
    itemChange(e){
      const index = e.currentTarget.dataset.index;
      this.triggerEvent("itemChange",index);
    }
  }
})
