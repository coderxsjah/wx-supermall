// components/cart/address/AddressView.js
import {getSetting,openSetting,chooseAddress} from "../../../utils/wxutils"
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    address:{
      type:Object,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    addAddress(){
      // console.log("添加地址")
      //通过微信内置api获取地址
      //获取用户地址授权状态信息scopeAddress
      getSetting().then(
        result=>{
          //特殊属性值名称不能直接用.获取，需要通过[属性名]获取
          const scopeAddress = result.authSetting["scope.address"];
          //scopeAddress为true表示已授权，undefined为初次调用 false表示已拒绝
          if(scopeAddress===false){
            openSetting();
          }
          chooseAddress().then(
            result1 =>{
              //console.log(result1);
              //将地址加入缓存中
              wx.setStorageSync("address", result1);
            }
          )
        }
      )
    }
  }
})
