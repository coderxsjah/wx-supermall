// components/goodsList/tab/Tab.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tabs:{
      type:Array,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currindex:0,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    select:function(e){
      this.setData({
        currindex:e.currentTarget.dataset.index,
      });
      this.triggerEvent("select",{selectIndex:e.currentTarget.dataset.index});
    }
  }
})
