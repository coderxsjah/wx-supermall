// components/goodsDetail/detailSwiper/DetailSwiper.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    pictures:{
      type:Array,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    handleImgPreview:function(e){
      console.log(e);
      const currindex = e.currentTarget.dataset.index;
      const urls = this.data.pictures.map(v=>{return v.pics_big})
      wx.previewImage({
        current: urls[currindex],
        urls: urls,
        success: (result)=>{
          
        },
        fail: ()=>{},
        complete: ()=>{}
      });
    }
  }
})
