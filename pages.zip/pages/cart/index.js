// pages/cart/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    allchecked:true,
    totalPrice:0,
    totalType:0,
    selected:false,//false表示一件都没选
  },

  addNum:function(e){
    const index = e.detail;
    this.data.cart[index].num ++;
    this.setData({
      cart:this.data.cart,
    })
    wx.setStorageSync("cart", this.data.cart);
    this.onShow();
  },
  subNum:function(e){
    const index = e.detail;
    if(this.data.cart[index].num>1){
      this.data.cart[index].num --;
      this.setData({
        cart:this.data.cart,
      })  
      wx.setStorageSync("cart", this.data.cart);
    }else{
      let cart = wx.getStorageSync("cart");
      cart[index].num--;
      cart.splice(index,1);
      wx.setStorageSync("cart", cart);
    }
    this.onShow();
  },
  //某项商品的checke状态改变
  itemChange(e){
    const index = e.detail;
    this.data.cart[index].checked = !this.data.cart[index].checked;
    this.setData({
      cart:this.data.cart,
    })
    wx.setStorageSync("cart", this.data.cart);
    this.onShow();
  },
  //全选改变
  allChange(){
    let allchecked=this.data.allchecked;
    let cart = this.data.cart;
    if(this.data.allchecked)
    {
      allchecked = false;
      for(let v of cart){
        v.checked = false;
      }
    }else{
      allchecked = true;
      for(let v of cart){
        v.checked = true;
      }
    }
    this.setData({
      allchecked,
      cart,
    })
    wx.setStorageSync("cart", this.data.cart);
    this.onShow();
  },
  //结算函数
  cartPay(){
    if(!this.data.address.userName){
      wx.showToast({
        title: '您还没有添加收货地址',
        icon:"none"
      });
    }
    else if(this.data.cart.length===0){
        wx.showToast({
          title: '您还没有选购商品',
          icon:"none"
        });
      }
    else if(!this.data.selected){
      wx.showToast({
        title:"您还没确定要结算的商品",
        icon:"none"
      })
    }
    else{
      // console.log("结算")
      wx.navigateTo({
        url: '/pages/pay/index',
      });
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const address = wx.getStorageSync("address")||{};
    const cart = wx.getStorageSync("cart")||[];
    const allchecked = cart.length===0? false : cart.every(v=>v.checked);
    let totalType = 0;
    let totalPrice = 0;
    let selected = false;
    //获取总价格及结算种类
    for(let v of cart){
      if(v.checked)
      {
        totalPrice += v.goods_price*v.num;
        totalType++;
        selected = true;
      }
    }
    this.setData({
      address,
      cart,
      allchecked,
      totalType,
      totalPrice,
      selected,
    })
    //console.log("onshow")
    //console.log(!address.userName)
    //获取allchecked
    
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const cart = wx.getStorageSync("cart");
    this.setData({
      cart,
    })
    console.log(cart);
    //console.log("onload")
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //console.log("onready")
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})