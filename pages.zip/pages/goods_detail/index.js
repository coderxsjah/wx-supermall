// pages/goods_detail/index.js
import {request} from "../../request/index.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods_id:0,
    goodsObj:{},//接受数据
    collected:false,//是否被收藏
  },
  //收藏商品
  collect(){
    let collections = wx.getStorageSync("collections")||[];
    this.setData({
      collected:!this.data.collected,
    })
    if(this.data.collected){
      wx.showToast({
        title: '收藏成功！',
      });
      collections.push(this.data.goodsObj);
    }
    else{
      wx.showToast({
        title: '取消收藏',
        icon: 'none',
      });
      const index = collections.findIndex(v=>{v.goods_id === this.data.goods_id})
      collections.splice(index,1);
    }
    wx.setStorageSync("collections", collections);
  },
  //获取商品详细数据
  getDetail(){
    request({url:"/goods/detail",data:{goods_id:this.data.goods_id}}).then(
      result=>{
        // console.log(result);
        this.setData({
          goodsObj:{goods_name:result.data.message.goods_name,
          goods_price:result.data.message.goods_price,
          //部分iphone不识别webp格式，需要修改为jpg,采用正则表达式替换
          goods_introduce:result.data.message.goods_introduce.replace(/\.webp/g,'.jpg'),
          pics:result.data.message.pics,
          goods_id:this.data.goods_id}
        })
      }
    )
  },
  //加入购物车
  addCart(){
    //获取缓存中的购物车数组
    let cart = wx.getStorageSync("cart")||[];
    //判断cart中是否存在此商品
    let index = -1;
    for(let i=0;i<cart.length;i++)
    {
      if(cart[i].goods_id===this.data.goods_id){
        index = i;
      }
    }
    // console.log(this.data.goods_id)
    // let index = cart.findIndex(v=>{v.goods_id==this.data.goods_id});
    if(index==-1){
      //不存在
      this.data.goodsObj.num=1;
      this.data.goodsObj.checked=true;
      cart.push(this.data.goodsObj);
    }else{
      cart[index].num++;
    }
    wx.setStorageSync("cart",cart);
    wx.showToast({
      title: '加入购物车成功',
      //防止手抖，只有15000ms后才能继续点击
      mask:true
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(typeof parseInt(options.goods_id))
    const goods_id = parseInt(options.goods_id);
    this.setData({
      goods_id
    });
    // console.log(this.data.goods_id)
    this.getDetail();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //判断收藏情况
    const collections = wx.getStorageSync("collections")||[];
    for(let v of collections){
      //console.log(v);
      if(v.goods_id===this.data.goods_id){
        //console.log("find")
        this.setData({
          collected:true,
        })
        break;
      }
      else{
        this.setData({
          collected:false,
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})