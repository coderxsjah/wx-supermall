// pages/category/index.js
import {request} from "../../request/index.js";
//import regeneratorRuntime from "../../lib/runtime/runtime.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    leftMenuList:[],
    rightContentList:[]
  },
  //获取商品分类数据
  //原始获取方法
  getCateList:function(){
    request({url:"/categories"}).then(
      (result) =>{
        //console.log(result.data.message)
        let leftMenuList = result.data.message.map(v=>{return v.cat_name});
        let rightContentList = result.data.message.map(v=>{return {lists:v.children}});
        this.setData({
          leftMenuList,
          rightContentList
        })
        //console.log(rightContentList)
        //存储数据到缓存
        wx.setStorageSync("Cates",{time:Date.now(),data:result.data.message})
      }
    )
  },
  //使用es7中async
  // async getCateList(){
  //     //1。使用es7的async 和await发送请求
  //     const res = await request({url:"/categories"});
  //     let leftMenuList = result.data.message.map(v=>{return v.cat_name});
  //     let rightContentList = result.data.message.map(v=>{return {lists:v.children}});
  //     this.setData({
  //       leftMenuList,
  //       rightContentList
  //     })
  //       //console.log(rightContentList)
  //       //存储数据到缓存
  //     wx.setStorageSync("Cates",{time:Date.now(),data:result.data.message})
  // },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //判断本地时候有未过期的缓存数据,
    const Cates = wx.getStorageSync("Cates");
    if(!Cates){
      this.getCateList();
    }else{
      //定义过期时间
      if(Date.now() - Cates.time>1000*5*60){
        this.getCateList();
      }else{
        let leftMenuList = Cates.data.map(v=>{return v.cat_name});
        let rightContentList = Cates.data.map(v=>{return {lists:v.children}});
        this.setData({
          leftMenuList,
          rightContentList
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})