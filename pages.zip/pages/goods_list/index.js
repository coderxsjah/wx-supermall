// pages/goods_list/index.js
import {request} from "../../request/index.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
      tabs:["综合","销量","价格"],
      currindex:0,
      goodsList:[],
  },
  //全局参数
  //url参数
  QueryParams:{
    query:"",
    cid:"",
    pagenum:1,
    pagesize:10
  },
  //总页数
  totalPages:1,
  //接受tab控制
  change(e){
    this.setData({
      currindex:e.detail.selectIndex,
    })
  },

  //获取商品列表数据
  getGoodsList(){
    request({url:"/goods/search",data:this.QueryParams}).then(
      result=>{
        //获取总条数
        const total = result.data.message.total;
        //计算总页数
        this.totalPages = Math.ceil(total / this.QueryParams.pagesize)
        this.setData({
          goodsList:[...this.data.goodsList,...result.data.message.goods],
        })
        //console.log(result.data.message.goods)
      }
    )

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //加载中
    wx.showLoading({
      title:"加载中" ,
      // mask: true,
      // success: (result)=>{   
      // },
      // fail: ()=>{},
      // complete: ()=>{}
    });
   // console.log(options);
    //获取商品的cid
    this.QueryParams.cid = options.cid||"";
    this.QueryParams.query = options.query||"";
    console.log(this.QueryParams);
    this.getGoodsList();
    // //关闭加载中
    // setTimeout(function(){
    //   wx.hideLoading()
    //  },5000) 
  },
    /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    //console.log("页面触底")
    if(this.QueryParams.pagenum > this.totalPages){
      // console.log("没有更多了")
      wx:wx.showToast({
        title: '没有更多了',
      });
    }else{
      this.QueryParams.pagenum++;
      console.log(this.QueryParams.pagenum)
      this.getGoodsList();
    }
  },
    /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    //重置数组
    this.setData({
      goodsList:[]
    });
    //重置页面
    this.QueryParams.pagenum=1;
    //重新请求数据
    this.getGoodsList();
    //停止下拉刷新
    wx.stopPullDownRefresh();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})