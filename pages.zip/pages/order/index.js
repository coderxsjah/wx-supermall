// pages/order/index.js
import {request} from "../../request/index.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabTitles:['全部订单','待付款','待收货','退货/退款'],
    currType:-1,
    orders:[],
  },
  tabClick(e){
    this.setData({
      currType:e.detail+1,
    })
    this.getOrders(this.data.currType);
  },
  //获取订单列表
  getOrders(type){
    //1获取token
    /*非企业账号，无法获取tokeny以下代码供企业账号参考*/
    // const token = wx.getStorageSync("token");
    // //2.判断
    // if(!token){
    //   //跳转到授权页面
    //   wx.navigateTo({
    //     url: '/pages/auth/index',
    //   });
    //   return;
    // }
    // //3准备请求头参数
    // const header = {Anthorization:token};
    // request({url:"/my/orders/all",header,data:{type}}).then(
    //   result=>{
    //     this.setData({
    //       orders:result.data.message.orders,
    //     })
    //   }
    // )
    let orders = ["全部订单"];
    switch(type){
      case 1: orders=["全部订单"];break;
      case 2: orders=["待付款"];break;
      case 3: orders=["待收货"];break;
      default:break;
    }
    this.setData({
      orders
    })
  },
   /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(this.data.currType===-1){
      //初次进入此页面
      //获取当前小程序页面栈
      let pages = getCurrentPages();
      //索引值最大的即为当前页面
      let currentPage = pages[pages.length-1]
      console.log(currentPage.options);
      const currType = parseInt(currentPage.options.type);
      this.setData({
        currType
      })
    }
    this.getOrders(this.data.currType);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})