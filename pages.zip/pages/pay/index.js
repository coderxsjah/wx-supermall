// pages/pay/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:{},
    cart:[],
    totalPrice:0,
    totalType:0,
  },
  //支付函数
  payPay(){
    console.log("payPay");
    //1.从缓存中获取token
    try{
      const token = wx.getStorageSync("token");
      //2.判断
      if(!token){
        //跳转到授权页面
        wx.navigateTo({
          url: '/pages/auth/index',
        });
        return;
      }
      else{
        console.log(token)
      }
      //3.创建订单
      //3.1准备请求头参数
      const header = {Anthorization:token};
      //3.2请求体参数
      const order_price = this.data.totalPrice;
      const consignee_addr = this.data.address.provinceName+this.data.address.cityName+this.data.address.countyName+this.data.address.detailInfo;
      const cart = this.data.cart;
      let goods = [];
      cart.forEach(v=>{goods.push({
        goods_id:v.goods_id,
        goods_number:v.num,
        goods_price:v.goods_price,
      })})
      const orderParams = {
        order_price,
        consignee_addr,
        goods,
      }
      //4.发送请求，创建订单，获取订单编号
      request({url:"/my/orders/create",data:orderParams,method:"POST"}).then(
        result=>{
          // console.log(result);
          const order_number = result.order_number;
          //5.发起预支付接口
          request({url:"/my/orders/req_unifiedorder",method:"POST",header,data:order_number}).then(
            result=>{
              const pay = result.pay;
              //6.发起微信支付
              wx.requestPayment({
                timeStamp: pay.timeStamp,
                nonceStr: pay.nonceStr,
                package: pay.package,
                signType: pay.signType,
                paySign: pay.sign,
                success: (result)=>{
                  //7.支付成功后查询订单装态
                  request({url:"/my/orders/chkOrder",method:"POST",header,data:{order_number}}).then(
                    result=>{
                      wx.showToast({
                        title: '支付成功！',
                      });
                    }
                  )
                  //将已经购买的商品从购物车中删除。。。
                  //8.跳转到订单页面
                  wx.navigateTo({
                    url:"/pages/order/index",
                  })
                },
              })
            }
          )
        }
      )
    }catch(err){
      wx.showToast({
        title: '支付失败！',
      });
      console.log(err);
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const address = wx.getStorageSync("address");
    const cart = wx.getStorageSync("cart");
    this.setData({
      address,
      cart,
    })
    console.log(cart)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    const address = wx.getStorageSync("address")||{};
    const cart = wx.getStorageSync("cart")||[];
    let totalType = 0;
    let totalPrice = 0;
    //获取总价格及结算种类
    for(let v of cart){
      if(v.checked)
      {
        totalPrice += v.goods_price*v.num;
        totalType++;
      }
    }
    this.setData({
      address,
      cart,
      totalType,
      totalPrice,
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})